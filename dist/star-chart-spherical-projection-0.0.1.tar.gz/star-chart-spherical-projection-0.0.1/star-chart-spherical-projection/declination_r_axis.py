########################################################################
# Distance between declination values in the radius are defined as either
#		Northern Hemsiphere = tan(45° - angle of inclination)
#		Southern Hemsiphere = tan(45° + angle of inclination)
########################################################################
import matplotlib.pyplot as plt
